# MyReads Project

## About

This is a Udacity Front-end Developer Project. The app built with React and API server was provided by Udacity. This app helps users to manage their reading habit. It allows user to add and search books from the server and catagorize them to 3 shelfs.

## Getting Started

1. download or clone this repository 
2. open Terminal and cd into this folder
3. run `npm install` in Terminal
4. run `npm start` to start the app :)